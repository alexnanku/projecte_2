package gimnas;

public class Telefon {
    
}
