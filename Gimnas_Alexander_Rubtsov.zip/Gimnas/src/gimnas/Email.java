package gimnas;

public class Email {
    
}
