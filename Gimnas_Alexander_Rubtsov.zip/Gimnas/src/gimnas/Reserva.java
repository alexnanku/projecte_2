package gimnas;

public class Reserva {
    
}
