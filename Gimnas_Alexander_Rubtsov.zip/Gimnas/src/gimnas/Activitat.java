package gimnas;

public class Activitat {
    
}
